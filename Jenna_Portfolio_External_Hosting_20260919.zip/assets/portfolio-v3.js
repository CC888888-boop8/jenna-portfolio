(() => {
  'use strict';

  const selectedCaseMedia = new Set([
    'assets/cases/fashion.svg',
    'assets/cases/education.svg',
    'assets/cases/tracking.svg',
    'assets/cases/food.svg',
    'assets/cases/tech.svg',
    'assets/cases/fitness.svg'
  ]);
  document.querySelectorAll('#more .r-case').forEach((card) => {
    const button = card.querySelector('.r-open');
    if (!button || !selectedCaseMedia.has(button.dataset.media)) card.remove();
  });
  const caseIntro = document.querySelector('#more .r-case-intro p');
  if (caseIntro) {
    caseIntro.textContent = '精選 6 個跨產業案例，以一張分析圖呈現問題、判讀與下一步。案例均由匿名工作資料重整，數據僅代表標示期間。';
  }
  document.querySelectorAll('#more .r-case').forEach((card, index) => {
    card.style.setProperty('--case-index', `'0${index + 1}'`);
  });

  const sectionCopy = {
    motion: '形象、活動、運動、婚禮與品牌影片，以剪輯節奏、畫面情緒和資訊層級，讓每支作品都能在 10 秒預覽中被快速理解。',
    graphic: '從編輯設計、活動識別到科技視覺，精選不同題材的靜態畫面，呈現構圖、色彩與資訊層級的設計判斷。',
    animation: '完整呈現動畫敘事、實拍合成與動態主視覺；每件作品皆可直接預覽，並可點擊放大播放。',
    storyboard: '以「挺立」完整分鏡為主，搭配生技與檢驗服務案例，呈現鏡頭規劃、場景轉換與製作溝通。'
  };
  Object.entries(sectionCopy).forEach(([id, copy]) => {
    const paragraph = document.querySelector(`#${id} .section-desc`);
    if (paragraph) paragraph.textContent = copy;
  });

  const graphicToolbar = document.querySelector('#graphic .r-toolbar');
  if (graphicToolbar) {
    graphicToolbar.innerHTML = '<span>VISUAL SELECTION / 06</span><span>點擊查看完整畫面</span>';
  }

  const graphicGrid = document.querySelector('#graphic .r-graphic-grid');
  if (graphicGrid) {
    graphicGrid.innerHTML = `
      <article class="r-work">
        <button class="r-open" type="button" data-media="assets/works/flat-forum.webp" data-kind="image" data-title="南島語族｜文化遺產論壇" aria-label="放大查看：南島語族｜文化遺產論壇">
          <div class="r-frame"><img src="assets/works/flat-forum.webp" loading="lazy" decoding="async" alt="南島語族文化遺產保護論壇視覺"><span class="r-mark">01 / EVENT</span></div>
          <div class="r-caption"><h3>南島語族｜文化遺產論壇</h3><p>文化符號、活動資訊與深色層次</p></div>
        </button>
      </article>
      <article class="r-work">
        <button class="r-open" type="button" data-media="assets/works/flat-peony.webp" data-kind="image" data-title="牡丹花｜婚禮識別" aria-label="放大查看：牡丹花｜婚禮識別">
          <div class="r-frame"><img src="assets/works/flat-peony.webp" loading="lazy" decoding="async" alt="深藍玫瑰金牡丹花婚禮識別"><span class="r-mark">02 / IDENTITY</span></div>
          <div class="r-caption"><h3>牡丹花｜婚禮識別</h3><p>深藍質地、玫瑰金與線描花卉</p></div>
        </button>
      </article>
      <article class="r-work">
        <button class="r-open" type="button" data-media="assets/works/flat-cosmetics.webp" data-kind="image" data-title="臺馬化粧品研討會｜直播視覺" aria-label="放大查看：臺馬化粧品研討會｜直播視覺">
          <div class="r-frame"><img src="assets/works/flat-cosmetics.webp" loading="lazy" decoding="async" alt="臺馬機能性天然物於化粧品研討會直播視覺"><span class="r-mark">03 / CONFERENCE</span></div>
          <div class="r-caption"><h3>臺馬化粧品研討會｜直播視覺</h3><p>透明感材質、柔光與雙語資訊</p></div>
        </button>
      </article>
      <article class="r-work">
        <button class="r-open" type="button" data-media="assets/works/flat-cover.webp" data-kind="image" data-title="虎躍創高峰｜新春形象視覺" aria-label="放大查看：虎躍創高峰｜新春形象視覺">
          <div class="r-frame"><img src="assets/works/flat-cover.webp" loading="lazy" decoding="async" alt="虎躍創高峰新春形象視覺"><span class="r-mark">04 / FESTIVE</span></div>
          <div class="r-caption"><h3>虎躍創高峰｜新春形象視覺</h3><p>節慶紋樣、煙火與醫療品牌整合</p></div>
        </button>
      </article>
      <article class="r-work">
        <button class="r-open" type="button" data-media="assets/works/flat-banner.webp" data-kind="image" data-title="Xing Ye｜花園書約" aria-label="放大查看：Xing Ye｜花園書約">
          <div class="r-frame"><img src="assets/works/flat-banner.webp" loading="lazy" decoding="async" alt="花園系列婚禮書約設計"><span class="r-mark">05 / STATIONERY</span></div>
          <div class="r-caption"><h3>Xing Ye｜花園書約</h3><p>留白、植物插畫與紙品情境呈現</p></div>
        </button>
      </article>
      <article class="r-work r-portrait">
        <button class="r-open" type="button" data-media="assets/works/flat-bluegold.webp" data-kind="image" data-title="藍金書約｜邀請設計" aria-label="放大查看：藍金書約｜邀請設計">
          <div class="r-frame"><img src="assets/works/flat-bluegold.webp" loading="lazy" decoding="async" alt="藍金筆觸婚禮邀請設計"><span class="r-mark">06 / PRINT</span></div>
          <div class="r-caption"><h3>藍金書約｜邀請設計</h3><p>深藍筆觸、金色質感與資訊秩序</p></div>
        </button>
      </article>`;
  }

  document.querySelectorAll('#motion .r-work').forEach((card, index) => {
    card.dataset.sequence = String(index + 1).padStart(2, '0');
  });
  document.querySelectorAll('#animation .r-animation-grid .r-work').forEach((card, index) => {
    card.dataset.sequence = String(index + 1).padStart(2, '0');
  });

  const keyvisualGrid = document.querySelector('#animation .r-keyvisual-grid');
  if (keyvisualGrid) {
    keyvisualGrid.innerHTML = `
      <article class="r-work"><button class="r-open" type="button" data-media="assets/previews/key-global.mp4" data-kind="video" data-title="Boston Scientific｜家庭日" aria-label="放大查看：Boston Scientific｜家庭日"><div class="r-frame"><video class="r-video" muted loop playsinline preload="none" poster="assets/previews/key-global.jpg" data-src="assets/previews/key-global.mp4" aria-label="Boston Scientific 家庭日 10 秒預覽"></video><span class="r-mark">▶ 10s</span></div><div class="r-caption"><h3>Boston Scientific｜家庭日</h3><p>高彩度插畫與音樂節奏的主視覺延展</p></div></button></article>
      <article class="r-work"><button class="r-open" type="button" data-media="assets/previews/key-startup.mp4" data-kind="video" data-title="第 21 屆｜新創事業獎" aria-label="放大查看：第 21 屆｜新創事業獎"><div class="r-frame"><video class="r-video" muted loop playsinline preload="none" poster="assets/previews/key-startup.jpg" data-src="assets/previews/key-startup.mp4" aria-label="第 21 屆新創事業獎 10 秒預覽"></video><span class="r-mark">▶ 10s</span></div><div class="r-caption"><h3>第 21 屆｜新創事業獎</h3><p>光線、獎座與科技空間的動態建構</p></div></button></article>
      <article class="r-work"><button class="r-open" type="button" data-media="assets/previews/key-copy.mp4" data-kind="video" data-title="臺灣文博會｜BRAVO 桃園" aria-label="放大查看：臺灣文博會｜BRAVO 桃園"><div class="r-frame"><video class="r-video" muted loop playsinline preload="none" poster="assets/previews/key-copy.jpg" data-src="assets/previews/key-copy.mp4" aria-label="臺灣文博會 BRAVO 桃園 10 秒預覽"></video><span class="r-mark">▶ 10s</span></div><div class="r-caption"><h3>臺灣文博會｜BRAVO 桃園</h3><p>城市符號、幾何拼貼與繽紛動態節奏</p></div></button></article>`;
  }
  document.querySelectorAll('#animation .r-keyvisual-grid .r-work').forEach((card, index) => {
    card.dataset.sequence = String(index + 1).padStart(2, '0');
  });

  const storyboardLead = document.querySelector('#storyboard .r-story-feature .r-caption h3');
  const storyboardLeadButton = document.querySelector('#storyboard .r-story-feature .r-open');
  if (storyboardLead) storyboardLead.textContent = '挺立｜完整分鏡選輯';
  if (storyboardLeadButton) {
    storyboardLeadButton.dataset.title = '挺立｜完整分鏡選輯';
    storyboardLeadButton.setAttribute('aria-label', '放大查看：挺立｜完整分鏡選輯');
  }
})();
