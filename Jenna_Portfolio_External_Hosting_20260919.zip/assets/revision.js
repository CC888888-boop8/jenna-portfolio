(() => {
  'use strict';
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const videos = [...document.querySelectorAll('.r-video')];
  const toggle = document.querySelector('.r-autoplay');
  let playing = !reduce.matches, lastFocus;
  const dialog = document.getElementById('r-viewer');
  const body = document.getElementById('r-viewer-body');
  const title = document.getElementById('r-viewer-title');
  const visible = new Set();
  const sync = () => {
    toggle.textContent = playing ? '暫停所有預覽' : '播放所有預覽';
    toggle.setAttribute('aria-pressed', String(playing));
    videos.forEach(v => {
      if (playing && visible.has(v) && !document.hidden && !dialog.open) {
        if (!v.getAttribute('src')) v.src = v.dataset.src;
        v.play().catch(() => {});
      } else v.pause();
    });
  };
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(e => e.isIntersecting ? visible.add(e.target) : visible.delete(e.target));
      sync();
    }, {threshold:.12});
    videos.forEach(v => observer.observe(v));
  } else videos.forEach(v => visible.add(v));
  toggle.addEventListener('click', () => {playing=!playing;sync();});
  document.addEventListener('visibilitychange', sync);
  reduce.addEventListener('change', () => {playing=!reduce.matches;sync();});
  document.querySelectorAll('.r-open').forEach(btn => btn.addEventListener('click', () => {
    lastFocus=btn; title.textContent=btn.dataset.title; body.replaceChildren();
    const media=document.createElement(btn.dataset.kind==='video'?'video':'img');
    media.src=btn.dataset.media;
    if (media instanceof HTMLVideoElement) {
      media.controls=true;media.muted=true;media.loop=true;media.playsInline=true;
      media.setAttribute('aria-label',btn.dataset.title+' 10 秒精華');
    } else media.alt=btn.dataset.title;
    body.append(media);dialog.showModal();document.body.classList.add('r-modal-open');sync();
    document.getElementById('r-viewer-close').focus();
    if (media instanceof HTMLVideoElement) media.play().catch(()=>{});
  }));
  document.getElementById('r-viewer-close').addEventListener('click',()=>dialog.close());
  dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
  dialog.addEventListener('close',()=>{body.querySelectorAll('video').forEach(v=>v.pause());body.replaceChildren();document.body.classList.remove('r-modal-open');lastFocus?.focus({preventScroll:true});sync();});
  sync();
})();
